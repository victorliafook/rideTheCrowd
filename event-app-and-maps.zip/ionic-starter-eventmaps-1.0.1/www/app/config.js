define([
  'app'
], function (app) {
  'use strict';
  // additional config-blocks
  // app.config([
  //   function () {
  //   }
  // ]);
});
